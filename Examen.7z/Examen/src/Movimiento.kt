import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*

fun main() {
    println("1 Agregar ")
    println("2 Salir")
    println("Elige una opción ")
    val menu: Int
    menu = try {
        readLine()?.toInt() as Int
    } catch (_: NumberFormatException) {
        0
    }

    operar(menu)

}

fun operar(menu: Int){

    val ListMovimientos = mutableListOf<ClsMovimientos>()
    val ListMovimientosNegativos = mutableListOf<ClsMovimientosNegativos>()
    val ListMovimientosPositivos = mutableListOf<ClsMovimientosPositivos>()

    if(menu == 1)
    {
        println("Cuantos movimientos desea hacer?")
        val qty: Int
        qty = try {
            readLine()?.toInt() as Int
        } catch (_: NumberFormatException) {
            0
        }

        if (qty !=0)
        {
            var x=0
            while (x < qty) {
                val Numbre=x+1
                println("Movimiento $Numbre")
                val monto: Int
                println("Ingrese un monto ")
                monto = try {
                    readLine()?.toInt() as Int
                } catch (_: NumberFormatException) {
                    0
                }
                val id = Numbre
                val year=2020+x
                ListMovimientos.add(ClsMovimientos(id, monto, year))
                x++
            }
            println("2. Punto ")
            ListMovimientos.sortByDescending({ it.Year })
            println(ListMovimientos.take(1))

            println("3. Punto ")
            ListMovimientos.sortByDescending({ it.Id })
            println(ListMovimientos.take(3))

            println("4. Punto ")
            ListMovimientos.forEach {
                if (it.Monto < 0)
                {
                    ListMovimientosNegativos.add(ClsMovimientosNegativos(it.Id, it.Monto, it.Year))
                }
                else{
                    ListMovimientosPositivos.add(ClsMovimientosPositivos(it.Id, it.Monto, it.Year))
                }
            }
            println("Map negativos ")
            val MapNegativos: Map<Int, String> = mapOf()
            ListMovimientosNegativos.forEach {
                println(MapNegativos + Pair(it.Monto, it.Id))
            }

            println("Map positivos ")
            val MapPositivos: Map<Int, String> = mapOf()
            ListMovimientosPositivos.forEach {
                println(MapPositivos + Pair(it.Monto, it.Id))
            }

            println("5. Punto ")
            val listid = ListMovimientos.filter { it.Monto >= 500000 }
            println(listid)
        }
        else{
            println("Solo se aceptan números")
        }

    }
    else if(menu==2)
    {
        println("Feliz día.")
    }
    else{
        println("Opción no valida")
    }
}

data class ClsMovimientos(val Id: Int, val Monto: Int, val Year: Int)
data class ClsMovimientosNegativos(val Id: Int, val Monto: Int, val Year: Int)
data class ClsMovimientosPositivos(val Id: Int, val Monto: Int, val Year: Int)
